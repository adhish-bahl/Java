/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab9;

/**
 *
 * @author adhis
 */
public class Lab9 {

    public static void main(String[] args) {
        new Home().setVisible(true);
    }
}
