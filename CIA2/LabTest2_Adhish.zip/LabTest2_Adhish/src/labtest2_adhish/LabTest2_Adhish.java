/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labtest2_adhish;

/**
 *
 * @author adhis
 */
public class LabTest2_Adhish {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Frame1().setVisible(true);
    }
    
}
